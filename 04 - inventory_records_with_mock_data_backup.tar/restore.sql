--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2
-- Dumped by pg_dump version 16.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "inventoryRecords";
--
-- Name: inventoryRecords; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "inventoryRecords" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_Canada.1252';


ALTER DATABASE "inventoryRecords" OWNER TO postgres;

\connect "inventoryRecords"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: contact; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contact (
    contact_id integer NOT NULL,
    contact_name character varying(50) NOT NULL,
    street character varying(50) NOT NULL,
    city character varying(50) NOT NULL,
    province character(2) NOT NULL,
    postal_code character(6) NOT NULL,
    email_address character varying(100) NOT NULL,
    phone_number character varying(15) NOT NULL
);


ALTER TABLE public.contact OWNER TO postgres;

--
-- Name: deliveries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.deliveries (
    delivery_id integer NOT NULL,
    warehouse_id integer NOT NULL,
    sales_id integer,
    delivery_date date NOT NULL,
    total_pieces integer NOT NULL
);


ALTER TABLE public.deliveries OWNER TO postgres;

--
-- Name: delivery_sales; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.delivery_sales (
    delivery_sales_id integer NOT NULL,
    delivery_id integer NOT NULL,
    sales_id integer NOT NULL
);


ALTER TABLE public.delivery_sales OWNER TO postgres;

--
-- Name: inventory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inventory (
    inventory_id integer NOT NULL,
    product_id integer NOT NULL,
    supplier_id integer NOT NULL,
    quantity_in_stock integer NOT NULL
);


ALTER TABLE public.inventory OWNER TO postgres;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    order_id integer NOT NULL,
    sales_id integer NOT NULL,
    contact_id integer NOT NULL,
    order_date date NOT NULL,
    total_order_value money NOT NULL
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: payment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payment (
    payment_id integer NOT NULL,
    sales_id integer NOT NULL,
    payment_date date NOT NULL,
    payment_amount money NOT NULL,
    payment_method character varying(50) NOT NULL
);


ALTER TABLE public.payment OWNER TO postgres;

--
-- Name: product; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product (
    product_id integer NOT NULL,
    product_name character varying(50) NOT NULL,
    sell_price money NOT NULL,
    cost_price money NOT NULL,
    amount_in_stock integer NOT NULL
);


ALTER TABLE public.product OWNER TO postgres;

--
-- Name: purchase; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.purchase (
    purchase_id integer NOT NULL,
    supplier_id integer NOT NULL,
    purchase_date date NOT NULL,
    total_cost money NOT NULL,
    delivery_id integer
);


ALTER TABLE public.purchase OWNER TO postgres;

--
-- Name: purchase_item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.purchase_item (
    purchase_item_id integer NOT NULL,
    purchase_id integer NOT NULL,
    product_id integer NOT NULL,
    quantity integer NOT NULL
);


ALTER TABLE public.purchase_item OWNER TO postgres;

--
-- Name: reward_points; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reward_points (
    reward_points_id integer NOT NULL,
    contact_id integer NOT NULL,
    points_earned integer NOT NULL,
    points_redeemed integer NOT NULL
);


ALTER TABLE public.reward_points OWNER TO postgres;

--
-- Name: sales; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sales (
    sales_id integer NOT NULL,
    salesperson_id integer NOT NULL,
    customer_id integer NOT NULL,
    sales_date date NOT NULL,
    total_revenue money NOT NULL
);


ALTER TABLE public.sales OWNER TO postgres;

--
-- Name: sales_item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sales_item (
    sales_item_id integer NOT NULL,
    sales_id integer NOT NULL,
    product_id integer NOT NULL,
    quantity integer NOT NULL,
    revenue_per_item money NOT NULL
);


ALTER TABLE public.sales_item OWNER TO postgres;

--
-- Name: salesperson; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.salesperson (
    salesperson_id integer NOT NULL,
    contact_id integer NOT NULL
);


ALTER TABLE public.salesperson OWNER TO postgres;

--
-- Name: salesperson_sales; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.salesperson_sales (
    salesperson_sales_id integer NOT NULL,
    salesperson_id integer NOT NULL,
    sales_id integer NOT NULL
);


ALTER TABLE public.salesperson_sales OWNER TO postgres;

--
-- Name: supplier; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.supplier (
    supplier_id integer NOT NULL,
    supplier_name character varying(50) NOT NULL,
    contact_id integer NOT NULL
);


ALTER TABLE public.supplier OWNER TO postgres;

--
-- Name: warehouse; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.warehouse (
    warehouse_id integer NOT NULL,
    warehouse_name character varying(50) NOT NULL,
    warehouse_city character varying(50) NOT NULL,
    sq_ft_capacity integer NOT NULL
);


ALTER TABLE public.warehouse OWNER TO postgres;

--
-- Data for Name: contact; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contact (contact_id, contact_name, street, city, province, postal_code, email_address, phone_number) FROM stdin;
\.
COPY public.contact (contact_id, contact_name, street, city, province, postal_code, email_address, phone_number) FROM '$$PATH$$/4942.dat';

--
-- Data for Name: deliveries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.deliveries (delivery_id, warehouse_id, sales_id, delivery_date, total_pieces) FROM stdin;
\.
COPY public.deliveries (delivery_id, warehouse_id, sales_id, delivery_date, total_pieces) FROM '$$PATH$$/4943.dat';

--
-- Data for Name: delivery_sales; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.delivery_sales (delivery_sales_id, delivery_id, sales_id) FROM stdin;
\.
COPY public.delivery_sales (delivery_sales_id, delivery_id, sales_id) FROM '$$PATH$$/4944.dat';

--
-- Data for Name: inventory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inventory (inventory_id, product_id, supplier_id, quantity_in_stock) FROM stdin;
\.
COPY public.inventory (inventory_id, product_id, supplier_id, quantity_in_stock) FROM '$$PATH$$/4945.dat';

--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (order_id, sales_id, contact_id, order_date, total_order_value) FROM stdin;
\.
COPY public.orders (order_id, sales_id, contact_id, order_date, total_order_value) FROM '$$PATH$$/4946.dat';

--
-- Data for Name: payment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payment (payment_id, sales_id, payment_date, payment_amount, payment_method) FROM stdin;
\.
COPY public.payment (payment_id, sales_id, payment_date, payment_amount, payment_method) FROM '$$PATH$$/4947.dat';

--
-- Data for Name: product; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product (product_id, product_name, sell_price, cost_price, amount_in_stock) FROM stdin;
\.
COPY public.product (product_id, product_name, sell_price, cost_price, amount_in_stock) FROM '$$PATH$$/4948.dat';

--
-- Data for Name: purchase; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.purchase (purchase_id, supplier_id, purchase_date, total_cost, delivery_id) FROM stdin;
\.
COPY public.purchase (purchase_id, supplier_id, purchase_date, total_cost, delivery_id) FROM '$$PATH$$/4949.dat';

--
-- Data for Name: purchase_item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.purchase_item (purchase_item_id, purchase_id, product_id, quantity) FROM stdin;
\.
COPY public.purchase_item (purchase_item_id, purchase_id, product_id, quantity) FROM '$$PATH$$/4950.dat';

--
-- Data for Name: reward_points; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reward_points (reward_points_id, contact_id, points_earned, points_redeemed) FROM stdin;
\.
COPY public.reward_points (reward_points_id, contact_id, points_earned, points_redeemed) FROM '$$PATH$$/4951.dat';

--
-- Data for Name: sales; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sales (sales_id, salesperson_id, customer_id, sales_date, total_revenue) FROM stdin;
\.
COPY public.sales (sales_id, salesperson_id, customer_id, sales_date, total_revenue) FROM '$$PATH$$/4952.dat';

--
-- Data for Name: sales_item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sales_item (sales_item_id, sales_id, product_id, quantity, revenue_per_item) FROM stdin;
\.
COPY public.sales_item (sales_item_id, sales_id, product_id, quantity, revenue_per_item) FROM '$$PATH$$/4953.dat';

--
-- Data for Name: salesperson; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.salesperson (salesperson_id, contact_id) FROM stdin;
\.
COPY public.salesperson (salesperson_id, contact_id) FROM '$$PATH$$/4954.dat';

--
-- Data for Name: salesperson_sales; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.salesperson_sales (salesperson_sales_id, salesperson_id, sales_id) FROM stdin;
\.
COPY public.salesperson_sales (salesperson_sales_id, salesperson_id, sales_id) FROM '$$PATH$$/4955.dat';

--
-- Data for Name: supplier; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.supplier (supplier_id, supplier_name, contact_id) FROM stdin;
\.
COPY public.supplier (supplier_id, supplier_name, contact_id) FROM '$$PATH$$/4956.dat';

--
-- Data for Name: warehouse; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.warehouse (warehouse_id, warehouse_name, warehouse_city, sq_ft_capacity) FROM stdin;
\.
COPY public.warehouse (warehouse_id, warehouse_name, warehouse_city, sq_ft_capacity) FROM '$$PATH$$/4957.dat';

--
-- Name: contact contact_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contact
    ADD CONSTRAINT contact_pkey PRIMARY KEY (contact_id);


--
-- Name: deliveries deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deliveries
    ADD CONSTRAINT deliveries_pkey PRIMARY KEY (delivery_id);


--
-- Name: delivery_sales delivery_sales_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivery_sales
    ADD CONSTRAINT delivery_sales_pkey PRIMARY KEY (delivery_sales_id);


--
-- Name: inventory inventory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_pkey PRIMARY KEY (inventory_id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (order_id);


--
-- Name: payment payment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment
    ADD CONSTRAINT payment_pkey PRIMARY KEY (payment_id);


--
-- Name: product product_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product
    ADD CONSTRAINT product_pkey PRIMARY KEY (product_id);


--
-- Name: purchase_item purchase_item_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_item
    ADD CONSTRAINT purchase_item_pkey PRIMARY KEY (purchase_item_id);


--
-- Name: purchase purchase_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase
    ADD CONSTRAINT purchase_pkey PRIMARY KEY (purchase_id);


--
-- Name: reward_points reward_points_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reward_points
    ADD CONSTRAINT reward_points_pkey PRIMARY KEY (reward_points_id);


--
-- Name: sales_item sales_item_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_item
    ADD CONSTRAINT sales_item_pkey PRIMARY KEY (sales_item_id);


--
-- Name: sales sales_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_pkey PRIMARY KEY (sales_id);


--
-- Name: salesperson salesperson_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.salesperson
    ADD CONSTRAINT salesperson_pkey PRIMARY KEY (salesperson_id);


--
-- Name: salesperson_sales salesperson_sales_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.salesperson_sales
    ADD CONSTRAINT salesperson_sales_pkey PRIMARY KEY (salesperson_sales_id);


--
-- Name: supplier supplier_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier
    ADD CONSTRAINT supplier_pkey PRIMARY KEY (supplier_id);


--
-- Name: warehouse warehouse_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse
    ADD CONSTRAINT warehouse_pkey PRIMARY KEY (warehouse_id);


--
-- Name: deliveries deliveries_sales_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deliveries
    ADD CONSTRAINT deliveries_sales_id_fkey FOREIGN KEY (sales_id) REFERENCES public.sales(sales_id);


--
-- Name: deliveries deliveries_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deliveries
    ADD CONSTRAINT deliveries_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouse(warehouse_id);


--
-- Name: delivery_sales delivery_sales_delivery_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivery_sales
    ADD CONSTRAINT delivery_sales_delivery_id_fkey FOREIGN KEY (delivery_id) REFERENCES public.deliveries(delivery_id);


--
-- Name: delivery_sales delivery_sales_sales_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivery_sales
    ADD CONSTRAINT delivery_sales_sales_id_fkey FOREIGN KEY (sales_id) REFERENCES public.sales(sales_id);


--
-- Name: inventory inventory_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.product(product_id);


--
-- Name: inventory inventory_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.supplier(supplier_id);


--
-- Name: orders orders_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public.contact(contact_id);


--
-- Name: payment payment_sales_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment
    ADD CONSTRAINT payment_sales_id_fkey FOREIGN KEY (sales_id) REFERENCES public.sales(sales_id);


--
-- Name: purchase_item purchase_item_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_item
    ADD CONSTRAINT purchase_item_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.product(product_id);


--
-- Name: purchase_item purchase_item_purchase_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_item
    ADD CONSTRAINT purchase_item_purchase_id_fkey FOREIGN KEY (purchase_id) REFERENCES public.purchase(purchase_id);


--
-- Name: purchase purchase_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase
    ADD CONSTRAINT purchase_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.supplier(supplier_id);


--
-- Name: reward_points reward_points_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reward_points
    ADD CONSTRAINT reward_points_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public.contact(contact_id);


--
-- Name: sales sales_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.contact(contact_id);


--
-- Name: sales_item sales_item_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_item
    ADD CONSTRAINT sales_item_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.product(product_id);


--
-- Name: sales_item sales_item_sales_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_item
    ADD CONSTRAINT sales_item_sales_id_fkey FOREIGN KEY (sales_id) REFERENCES public.sales(sales_id);


--
-- Name: sales sales_salesperson_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_salesperson_id_fkey FOREIGN KEY (salesperson_id) REFERENCES public.salesperson(salesperson_id);


--
-- Name: salesperson salesperson_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.salesperson
    ADD CONSTRAINT salesperson_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public.contact(contact_id);


--
-- Name: salesperson_sales salesperson_sales_sales_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.salesperson_sales
    ADD CONSTRAINT salesperson_sales_sales_id_fkey FOREIGN KEY (sales_id) REFERENCES public.sales(sales_id);


--
-- Name: salesperson_sales salesperson_sales_salesperson_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.salesperson_sales
    ADD CONSTRAINT salesperson_sales_salesperson_id_fkey FOREIGN KEY (salesperson_id) REFERENCES public.salesperson(salesperson_id);


--
-- Name: supplier supplier_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier
    ADD CONSTRAINT supplier_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public.contact(contact_id);


--
-- PostgreSQL database dump complete
--

